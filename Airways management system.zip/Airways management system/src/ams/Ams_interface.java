package ams;

public interface Ams_interface {
    
    abstract void showInfo();
    
}
