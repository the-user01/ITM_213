 package ams;

public class Ticket_info implements Ams_interface{
    
    private String fName,lName, dept_time, return_time;
    private int con_num;

    public String getfName() {
        return fName;
    }

    public void setfName(String fName) {
        this.fName = fName;
    }

    public String getLName() {
        return lName;
    }

    public void setLName(String lName) {
        this.lName = lName;
    }

    public int getCon_num() {
        return con_num;
    }

    public void setCon_num(int con_num) {
        this.con_num = con_num;
    }
    

    public String getDept_time() {
        return dept_time;
    }

    public void setDept_time(String dept_time) {
        this.dept_time = dept_time;
    }

    public String getReturn_time() {
        return return_time;
    }

    public void setReturn_time(String return_time) {
        this.return_time = return_time;
    }
    
    @Override
    public void showInfo(){
        
        System.out.println();
        
           for (int i = 1; i <= 35; i++) {
            System.out.print(" "+"-");
        }
        System.out.println();
        
        for (int i = 1; i <= 15; i++) {
            System.out.print(" ");
        }
        
        System.out.println("**** Booking Confirmation ****");
        
        for (int i = 1; i <= 35; i++) {
            System.out.print(" "+"-");
        }
        
        System.out.println();
        System.out.println();
        
        
        System.out.println("Name: "+fName + " " + lName);
        System.out.println("Contact Number: "+con_num);
        System.out.println("Departure Date: "+dept_time + "      "+ "Return Date: "+return_time);
    }


    
}
