package ams;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
    
        Message mes = new Message();
        mes.message(); // providing intro message
        
       // Ticket Information
        
        Ticket_info ti = new Ticket_info(); 
        Ticket_price tp = new Ticket_price();
        
/*----------------------------------------------------------------*/  

        // Confirmation
        
        System.out.println();
        System.out.println("Available Routes: ");
        System.out.println();
        
        tp.showAirport();
        System.out.println();
        
        System.out.println("Do you want to buy ticket?");
        System.out.println("1. Yes");
        System.out.println("1. No");
        System.out.println();
        
        System.out.print("Press 1 or 2: ");
        int conf = input.nextInt();
        
        if(conf>0 && conf<3){
            
            if(conf==1){
                
                // Ticket registration
                
                System.out.println();

                System.out.print("Enter your First Name: ");
                String fName = input.next();

                System.out.print("Enter your Last Name: ");
                String lName = input.next();

                System.out.print("Enter Contact Number: ");
                int con_num = input.nextInt();

                System.out.print("Departure Date: ");
                String dept_time = input.next();

                System.out.print("Return Date: ");
                String return_time = input.next();

        /*----------------------------------------------------------------*/

                // Route design 

                System.out.println();

                tp.showAirport();

                System.out.println();

                System.out.print("Choose route no: ");
                int route_no = input.nextInt();

                System.out.print("How many tickets you want to buy: ");
                int quantity = input.nextInt();

                tp.selectRoute(route_no, quantity, dept_time);

        /*-------------------------------------------------------------------*/

                // passing user info

                ti.setfName(fName);
                ti.setLName(lName);
                ti.setCon_num(con_num);
                ti.setDept_time(dept_time);
                ti.setReturn_time(return_time);

        /*-------------------------------------------------------------------*/

                // Show Booking Info

                ti.showInfo(); // Ticket Information
                tp.showInfo(); // Route && price intfo

            }
            else if(conf==2){
                System.out.println();
                System.out.println("Thank you for visiting us");
                System.out.println();
            }
            
        }
        else{
            
            System.out.println();
            System.out.println("Press 1 or 2");
            System.out.println();
            
        } // confirmation
        
        
        
    } // Main function
    
} // Main class






/*

Name: A.S.M Tawfiqul Hasan
Id: 211-51-047
Batch: 3rd
Department of Information Technology and Management

*/