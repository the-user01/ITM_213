package ams;

public class Message {
    void message(){
         for (int i = 1; i <= 35; i++) {
            System.out.print(" "+"-");
        }
        System.out.println();
        
        for (int i = 1; i <= 15; i++) {
            System.out.print(" ");
        }
        
        System.out.println("**** Welcome to O'muk Airlines ****");
        
        for (int i = 1; i <= 35; i++) {
            System.out.print(" "+"-");
        }
        System.out.println();
        System.out.println();
        
    }
}
