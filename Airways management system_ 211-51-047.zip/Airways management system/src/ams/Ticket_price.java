package ams;

public class Ticket_price implements Ams_interface{
    
    int amount, quantity, route_no;
    String flying_from, flying_to, dept_time;
    
    void showAirport(){
        
        System.out.println("1. Dhaka to Chittagong. Ticket Price: BDT 4000");
        System.out.println("2. Dhaka to Cox's Bazar. Ticket Price: BDT 4500");
        System.out.println("3. Dhaka to Barishal. Ticket Price: BDT 3000");
        System.out.println("4. Dhaka to Sylhet. Ticket Price: BDT 3500");
        
    }
    
    void selectRoute(int route_no, int quantity, String dept_time){
        this.route_no = route_no; // Taking number of ticket info
        this.quantity = quantity; // Taking number of ticket info
        this.dept_time = dept_time; // Taking number of ticket info
        
        switch(route_no){
            
            case 1:
                flying_from = "Dhaka" ;
                flying_to = "Chittagong";
                        
                amount = 4000*quantity;
                break;
                
            case 2:
                flying_from = "Dhaka" ;
                flying_to = "Cox's Bazar";
                     
                amount = 4500*quantity;
                break;
                
            case 3:
                flying_from = "Dhaka" ;
                flying_to = "Barishal";
                     
                amount = 3000*quantity;
                break;
                
            case 4:
                flying_from = "Dhaka" ;
                flying_to = "Sylhet";
                     
                amount = 3500*quantity;
                break;
        }
    }
    
     public void flight_schedule(){
        
          switch(route_no){
            
            case 1:
                System.out.println("Flight: "+dept_time+", 10:30AM");
                break;
                
            case 2:
                System.out.println("Flight: "+dept_time+", 2:30AM");
                break;
                
            case 3:
               System.out.println("Flight: "+dept_time+", 10:30AM");
                break;
                
            case 4:
                System.out.println("Flight: "+dept_time+", 11:00PM");
                break;
        }
        
    }
    
        @Override
        public void showInfo(){
        System.out.println("Flying From: "+flying_from + "            " + "Flying To: "+flying_to);
        
        System.out.println();
        
        System.out.println("Number of tickets: "+ quantity);
        System.out.println("Ticket Price: BDT "+amount);
        
        System.out.println();
        
        flight_schedule(); // Showing Flight Schedule
        
        System.out.println();

        System.out.println("      **** YOUR BOOKING IS SUCCESSFUL! ****");
        System.out.println();
        System.out.println("**** Thanks for purchasing, Enjoy your journey ****");
        System.out.println();
    }
        
}
