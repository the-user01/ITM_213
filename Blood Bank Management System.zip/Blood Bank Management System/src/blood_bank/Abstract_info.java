package blood_bank;

public abstract class Abstract_info {
    
    public abstract void showInfo();
    
}
