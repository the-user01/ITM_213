package blood_bank;

public class Donor_info extends Abstract_info {
    
    private String f_name, l_name, b_type, height, weight;
    private int age, phone;

    public String getF_name() {
        return f_name;
    }

    public void setF_name(String f_name) {
        this.f_name = f_name;
    }

    public String getL_name() {
        return l_name;
    }

    public void setL_name(String l_name) {
        this.l_name = l_name;
    }

    

    public String getB_type() {
        return b_type;
    }

    public void setB_type(String b_type) {
        this.b_type = b_type;
    }

    public String getHeight() {
        return height;
    }

    public void setHeight(String height) {
        this.height = height;
    }

    public String getWeight() {
        return weight;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public int getPhone() {
        return phone;
    }

    public void setPhone(int phone) {
        this.phone = phone;
    }
    
    
    
    
    @Override
    public void showInfo(){
        
        System.out.println();
        
        System.out.println("***** Donor Info *****");
        
        System.out.println();
        
        System.out.println("Name: "+ f_name + " "+ l_name);
        System.out.println("Age: "+age);
        System.out.println("Contact Number: "+ phone);
        System.out.println();
        System.out.println("Height: "+height);
        System.out.println("Weight: "+ weight+" kg");
        System.out.println("Blood Type: "+ b_type);
        
        System.out.println();
        
    }
    
}
