package blood_bank;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        // Intro message
        Message m = new Message();
        m.message();
       
        // Creating Objects
        
        Donor_info di = new Donor_info();
        Receipient_info ri = new Receipient_info();
        
        System.out.println();
        
        System.out.println("Choose option: ");
        System.out.println();
        System.out.println("1. Blood Donation");
        System.out.println("2. Get Blood");
        System.out.println();
        System.out.print("Press 1 or 2: ");
        int option = input.nextInt();
        System.out.println();
        
        if(option>0 && option<3){
            
            if(option == 1){
                System.out.println("Donor Information");
                System.out.println();
                
                System.out.print("Enter your first name: ");
                String f_name = input.next();
                
                System.out.print("Enter your last name: ");
                String l_name = input.next();
                
                System.out.print("Age: ");
                int age = input.nextInt();
                
                System.out.print("Contact Number: ");
                int phone = input.nextInt();
                
                System.out.print("Height: ");
                String height = input.next();                 
                
                System.out.print("Weight: ");
                String  weight = input.next();
                
                System.out.print("Blood Type: ");
                String b_type = input.next();
                
                di.setF_name(f_name);
                di.setL_name(l_name);
                di.setAge(age);
                di.setPhone(phone);
                di.setHeight(height);
                di.setWeight(weight);
                di.setB_type(b_type);
                
                // showing donor message
                di.showInfo();
                
            } // Donor Info
            else if(option == 2){
                System.out.println("Blood Receipient Information");
                System.out.println();
                
                System.out.print("Enter your first name: ");
                String f_name = input.next();
                
                System.out.print("Enter your last name: ");
                String l_name = input.next();
                
                System.out.print("Hospital Name: ");
                String h_name = input.next(); 
                
                System.out.print("Contact Number: ");
                int phone = input.nextInt();
                
                System.out.print("Required Blood Type: ");
                String b_type = input.next();
                
                System.out.print("Blood Quantity: ");
                int quantity = input.nextInt();
                
                ri.setF_name(f_name);
                ri.setL_name(l_name);
                ri.setPhone(phone);
                ri.setH_name(h_name);
                ri.setB_type(b_type);
                ri.setQuantity(quantity);
                
                // showing receipnt info
                ri.showInfo();
                
                
            } // Receipient Info
            
        }
        else{
            System.out.println();
            System.out.println("Press 1 or 2");
            System.out.println();
        }
        
    }
    
}
