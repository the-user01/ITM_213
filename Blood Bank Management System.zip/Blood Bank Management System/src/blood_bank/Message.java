package blood_bank;

public class Message {
    void message(){
         for (int i = 1; i <= 35; i++) {
            System.out.print(" "+"-");
        }
        System.out.println();
        
        for (int i = 1; i <= 21; i++) {
            System.out.print(" ");
        }
        
        System.out.println("Tista Blood Bank");
        
        for (int i = 1; i <= 35; i++) {
            System.out.print(" "+"-");
        }
        System.out.println();
        System.out.println();
        
    }
}
