package blood_bank;

public class Receipient_info extends Abstract_info {
    private String f_name, l_name, b_type, h_name;
    private int  phone, quantity;

    public String getF_name() {
        return f_name;
    }

    public void setF_name(String f_name) {
        this.f_name = f_name;
    }

    public String getL_name() {
        return l_name;
    }

    public void setL_name(String l_name) {
        this.l_name = l_name;
    }

    public String getB_type() {
        return b_type;
    }

    public void setB_type(String b_type) {
        this.b_type = b_type;
    }

    public String getH_name() {
        return h_name;
    }

    public void setH_name(String h_name) {
        this.h_name = h_name;
    }

    public int getPhone() {
        return phone;
    }

    public void setPhone(int phone) {
        this.phone = phone;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
    
    
    
    @Override
    public void showInfo(){
        System.out.println();
        System.out.println("***** Receipnt Information *****");
        System.out.println();
        
        System.out.println("Name: "+ f_name + " "+ l_name);
        System.out.println("Contact Number: "+ phone);
        System.out.println("Hospital Name: "+ h_name);
        System.out.println("Blood Type: "+ b_type);
        System.out.println("Blood Quantity: "+ quantity +" bag");
        
        System.out.println();
        
    }
    
}
