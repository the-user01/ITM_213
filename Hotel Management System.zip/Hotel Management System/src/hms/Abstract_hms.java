package hms;

public abstract class Abstract_hms {
    
    public abstract void show_info();
    
}


/* 

Name: Md Sadnan Sadad Shourov
Id: 211-51-039

*/