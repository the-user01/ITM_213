package hms;

public class Information extends Abstract_hms{
    
    private String first_name, last_name , gender, check_in, check_out;
    private int age, voter_id, contact;

    public String getFirst_name() {
        return first_name;
    }

    public void setFirst_name(String first_name) {
        this.first_name = first_name;
    }

    public String getLast_name() {
        return last_name;
    }

    public void setLast_name(String last_name) {
        this.last_name = last_name;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public int getContact() {
        return contact;
    }

    public void setContact(int contact) {
        this.contact = contact;
    }
    

    public String getCheck_in() {
        return check_in;
    }

    public void setCheck_in(String check_in) {
        this.check_in = check_in;
    }

    public String getCheck_out() {
        return check_out;
    }

    public void setCheck_out(String check_out) {
        this.check_out = check_out;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public int getVoter_id() {
        return voter_id;
    }

    public void setVoter_id(int voter_id) {
        this.voter_id = voter_id;
    }
    
    // Showing Information
    
    @Override
    public void show_info(){
        System.out.println();
        System.out.println();
        
        System.out.println("****** Booking Confirmation ******");
        
        System.out.println();
        
        System.out.println("Name: "+ first_name+" "+last_name);
        System.out.println("Age: "+ age);
        System.out.println("Gender: "+gender);
        System.out.println("Contact Number: "+contact);
        System.out.println("National Id No: "+ voter_id);
        
        System.out.println();
        
        System.out.println("Check in date: "+check_in);
        System.out.println("Check out date: "+check_out);
        
    }
    
}
