package hms;

public class Intro_message {
     void message(){
         for (int i = 1; i <= 35; i++) {
            System.out.print(" "+"-");
        }
        System.out.println();
        
        for (int i = 1; i <= 15; i++) {
            System.out.print(" ");
        }
        
        System.out.println("**** Welcome to The Prince ****");
        
        for (int i = 1; i <= 35; i++) {
            System.out.print(" "+"-");
        }
        System.out.println();
        System.out.println();
        
    }
}
