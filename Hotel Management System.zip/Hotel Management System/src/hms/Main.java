package hms;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        Intro_message m = new Intro_message();
        m.message(); // Showing message
        
        // Declaring objects here
        
        Information info = new Information();
        Room_details rd = new Room_details();
           
        // Room Information
        
        System.out.println("Available rooms: ");
        rd.show_rooms(); // get room details
        rd.confirmation(); // get confirmation for booking
        
        // getting user information
        
        System.out.print("Press 1 or 2: ");
        int num = input.nextInt();
        
        if(num>0 && num<3){
            
            if(num == 1){
                
                // Getting user information
                
                System.out.println();
                
                System.out.print("Enter first name: ");
                String first_name = input.next();
                
                System.out.print("Enter last name: ");
                String last_name = input.next();
                
                System.out.print("Age: ");
                int age = input.nextInt();
                
                System.out.print("Enter Gender: ");
                String gender = input.next();
                
                System.out.print("Enter Contact number: ");
                int contact = input.nextInt();
                
                System.out.print("Enter National Id no: ");
                int voter_id = input.nextInt();
                
                System.out.print("Check In date: ");
                String check_in = input.next();
                
                System.out.print("Check Out date: ");
                String check_out = input.next();
                
                
                info.setFirst_name(first_name);
                info.setLast_name(last_name);
                info.setAge(age);
                info.setGender(gender);
                info.setContact(contact);
                info.setVoter_id(voter_id);
                info.setCheck_in(check_in);
                info.setCheck_out(check_out);
                
                
                // Geeting room information
                
                rd.show_rooms();
                
                System.out.print("Enter room number: ");
                int room_no = input.nextInt() ;
                
                System.out.print("How many rooms do you want to book: ");
                int num_room = input.nextInt();
                        
                System.out.print("Number of days you want to stay: ");
                int stay = input.nextInt();
                
                rd.price(room_no, num_room, stay);
                
                // Showing Information
                
                info.show_info();
                rd.show_info();
                
            }
            else if(num == 2){
                System.out.println();
                System.out.println("Thank you for coming");
                System.out.println();
            }
        }
        else{
            System.out.println("Press 1 or 2");
        }
    
        System.out.println();
        System.out.println();

    }
    
}
