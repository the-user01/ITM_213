package hms;

public class Room_details extends Abstract_hms {
    
    // Room price message
    
    public void show_rooms(){
        System.out.println();
        
        System.out.println("1. Single bed 600 BDT");
        System.out.println("2. Double bed 1000 BDT");
        
        System.out.println();
    }
    
    // Room booking confirmation
    
    public void confirmation(){
        System.out.println("Do you want book a room?");
        System.out.println("1. Yes.");
        System.out.println("2. No.");
        System.out.println();
    }
    
    // Room booking Price
    
    int room_no, num_room,stay, price;
    
    public void price(int room_no, int num_room, int stay){
        this.room_no  = room_no;
        this.num_room  = num_room;
        this.stay  = stay;
        
        if(room_no == 1){
            price = 600 * num_room * stay;
        }
        else if(room_no == 2){
            price = 1000 * num_room * stay;
        } 
    }
    
    @Override
    public void show_info(){
        System.out.println();
        System.out.println("Number of rooms: "+ num_room);
        System.out.println("Bill Amount: "+ price+" BDT");
        System.out.println();
    }
    
}
