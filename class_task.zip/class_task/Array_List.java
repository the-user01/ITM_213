package class_task;
import java.util.ArrayList;

public class Array_List {
    public static void main(String[] args) {
        ArrayList<String> cars = new ArrayList<String>();
        
        cars.add("Volvo"); // adding element in the array
        cars.add("BMW");
        cars.add("Ford");
        cars.add("Mazda");
        
        /*
        System.out.println(cars);
        
        System.out.println(cars.get(0)); // get individual element from the array
        
        cars.set(0, "Opel"); // Modify an element
        
        System.out.println(cars);
        
        System.out.println(cars.size()); // get the size
        
        cars.clear();
        System.out.println(cars);
*/
        
        for (int i = 0; i < cars.size(); i++) {
            System.out.println(cars.get(i));
        }
        
    }
}
