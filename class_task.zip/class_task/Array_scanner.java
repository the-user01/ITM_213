
package class_task;

import java.util.ArrayList;
import java.util.Scanner;

public class Array_scanner {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        ArrayList<Integer> car = new ArrayList<Integer>();
        
        for (int i = 0; i < 3; i++) {
            
        car.add(input.nextInt());
            
        }
      
        System.out.println();
        
        for (int i = 0; i < car.size(); i++) {
        System.out.println(car.get(i));
        }
        
    }
    
}
