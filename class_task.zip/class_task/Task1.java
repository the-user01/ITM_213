
package class_task;

import java.util.ArrayList;
import java.util.Scanner;

public class Task1 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        ArrayList<Integer> num = new ArrayList<Integer>();
        
        num.add(5);
        num.add(3);
        num.add(12);
        num.add(20);
        num.add(35);
        num.add(15);
        num.add(50);
        num.add(10);
        
        int xy = input.nextInt();
        int count =0;
        
        for (int i = 0; i < num.size(); i++) {
            
            if(xy == num.get(i)){
                count++;
                break;
            }
            
        }
        
        if(count == 1){
            System.out.println("Matched");
        }
        else{
            System.out.println("Didn't Match");
        }
        
    }
    
}
