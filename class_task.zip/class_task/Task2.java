
package class_task;

import java.util.ArrayList;
import java.util.Scanner;

public class Task2 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        ArrayList<String> num = new ArrayList<String>();
        
        num.add("Sakib");
        num.add("Hasan");
        num.add("Rafiq");
        num.add("Mahbub");
       
        String xy = input.next();
        int count =0;
        
        for (int i = 0; i < num.size(); i++) {
            
            if(xy.equals(num.get(i))){
                count++;
                break;
            }
        }
        
        if(count == 1){
            System.out.println("Matched");
        }
        else{
            System.out.println("Didn't Match");
        }
        
    }
    
}
