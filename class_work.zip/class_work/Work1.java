
package class_work;

import java.util.Scanner;

public class Work1 {
     public static void main(String[] args){
        
        Scanner input = new Scanner(System.in);
        
         System.out.printf("Calculator\n\n");
        
        // Taking number input
        double num_1, num_2, result;
        
        System.out.print("Enter first number: ");
        num_1 = input.nextDouble();
        
        System.out.print("Enter second number: ");
        num_2 = input.nextDouble();
        
         System.out.println();
        
        // Taking Operator input
        int op;
         System.out.println("Press 1 for Addition");
         System.out.println("Press 2 for Substraction");
         System.out.println("Press 3 for Multiplication");
         System.out.println("Press 4 for Division");
         
         System.out.println();
         
        System.out.print("Enter operator number: ");
        op = input.nextInt();
        
         System.out.println();
        
        
        if(op<1 || op>4){
            System.out.println("This is not an operator!");  
        }
        else{
             
            switch(op){
                case 1 :
                    result = num_1 + num_2;
                    System.out.printf("%.0f + %.0f = %.0f \n", num_1, num_2, result);
                    break;
                    
                case 2 :
                    result = num_1 - num_2;
                    System.out.printf("%.0f - %.0f = %.0f \n" ,num_1, num_2, result);
                    break;

                case 3:
                    result = num_1 * num_2;
                    System.out.printf("%.0f X %.0f = %.0f \n", num_1, num_2, result);
                    break;

                case 4:
                    result = num_1 / num_2;
                    System.out.printf("%.0f / %.0f = %f \n", num_1, num_2, result);
                    break;
            }
        }
    }   
}
