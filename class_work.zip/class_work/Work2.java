package class_work;

import java.util.Scanner;

public class Work2 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        System.out.print("Input number of terms: ");
        int num = input.nextInt();
        
        for (int i = 1; i <= num; i++) {
            System.out.println("Number is : "+i+" and the cube of "+i+" is : "+(i*i*i));
        }
    }
}
