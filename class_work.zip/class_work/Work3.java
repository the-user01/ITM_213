
package class_work;

import java.util.Scanner;

public class Work3 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
       /* int [] serial = {1,2,3};
        String [] name = {"Maruf", "Mehedi", "Fahmida"};
        String [] gender = {"Male", "Male", "Female"};
       */
        
        int [] serial = new int[2];
        String [] name = new String[2];
        String [] gender = new String[2];
        
        System.out.println("Enter serial number, name and gender: ");
        
        for (int i = 0; i < 2; i++) {
            serial[i] = input.nextInt();
            name[i] = input.nextLine();
            gender[i] = input.next();
        }
        
        System.out.println();
        
        System.out.println("No. Name Gender");
        
        for (int i = 0; i < 2; i++) {
            System.out.println(serial[i]+" "+name[i]+" "+gender[i]);
        }
                
    } 
}
