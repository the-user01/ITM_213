
package online_banking;

public class Bkash implements OnlineBankingInterface{

    @Override
    public void paymentConfirmation() {
        System.out.println("Payment Confirmed by Bkash");
    }

    @Override
    public float paymentCharge() {
        return 18.50f;
    }
    
}
