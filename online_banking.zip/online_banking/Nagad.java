package online_banking;

public class Nagad implements OnlineBankingInterface {

    @Override
    public float paymentCharge() {
        return 9.99f;
    }

    @Override
    public void paymentConfirmation() {
        System.out.println("Payment Confirmed by Nagad");
    }
    
}
