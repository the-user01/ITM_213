package online_banking;

public abstract class OnlineBanking {

    public float paymentCharge(){
        return 10.00f;
    }
    
    public abstract void paymentConfirmation();
    
}
