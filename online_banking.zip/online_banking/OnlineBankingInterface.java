
package online_banking;

public interface OnlineBankingInterface {
    
     public float paymentCharge();
     
    public void paymentConfirmation();
    
}
