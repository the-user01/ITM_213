package online_banking;

public class Rocket implements OnlineBankingInterface {
    
    @Override
    public float paymentCharge() {
        return 16.9f;
    }

    @Override
    public void paymentConfirmation() {
        System.out.println("Payment Confirmed by Rocket");
    }
}
